# Release Engineering

We're trying out a new Concourse CI/CD pipeline for automating the
testing, vetting, and releasing of Genesis Kits, and this kit is
in the trial runs.
